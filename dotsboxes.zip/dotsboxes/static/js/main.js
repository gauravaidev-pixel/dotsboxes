(() => {
  'use strict';

  // ---------------------------------------------------------------
  // DOM refs
  // ---------------------------------------------------------------
  const screens = {
    lobby: document.getElementById('lobbyScreen'),
    wait: document.getElementById('waitScreen'),
    game: document.getElementById('gameScreen'),
  };

  const el = (id) => document.getElementById(id);
  const toastHost = el('toastHost');

  function showScreen(name) {
    Object.values(screens).forEach(s => s.classList.add('hidden'));
    screens[name].classList.remove('hidden');
  }

  function toast(message, kind) {
    const t = document.createElement('div');
    t.className = 'toast' + (kind ? ` toast-${kind}` : '');
    t.textContent = message;
    toastHost.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }

  // ---------------------------------------------------------------
  // Lobby tabs
  // ---------------------------------------------------------------
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
      el(`tab-${btn.dataset.tab}`).classList.remove('hidden');
    });
  });

  el('vsAiCheck').addEventListener('change', (e) => {
    el('aiDiffRow').classList.toggle('hidden', !e.target.checked);
    el('nameG_local').closest('.field-row').classList.toggle('hidden', e.target.checked);
  });

  // ---------------------------------------------------------------
  // Shared SVG board renderer
  // ---------------------------------------------------------------
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const VB = 800;
  let boardEls = null; // {lines: Map(key->{hit,visible}), boxes: Map(key->{rect,text}), size}

  function buildBoard(svg, size) {
    svg.innerHTML = '';
    const spacing = VB / (size + 1);
    const lineMap = new Map();
    const boxMap = new Map();

    // box fills (drawn first, below everything)
    for (let y = 0; y < size - 1; y++) {
      for (let x = 0; x < size - 1; x++) {
        const dx = spacing + x * spacing, dy = spacing + y * spacing;
        const rect = document.createElementNS(SVG_NS, 'rect');
        rect.setAttribute('x', dx + 4);
        rect.setAttribute('y', dy + 4);
        rect.setAttribute('width', spacing - 8);
        rect.setAttribute('height', spacing - 8);
        rect.setAttribute('rx', 6);
        rect.setAttribute('class', 'box-fill');
        rect.setAttribute('fill', 'transparent');
        svg.appendChild(rect);

        const text = document.createElementNS(SVG_NS, 'text');
        text.setAttribute('x', dx + spacing / 2);
        text.setAttribute('y', dy + spacing / 2);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('dominant-baseline', 'central');
        text.setAttribute('font-size', Math.max(16, spacing / 2.6));
        text.setAttribute('class', 'box-label');
        text.setAttribute('fill', 'transparent');
        svg.appendChild(text);

        boxMap.set(`${x},${y}`, { rect, text });
      }
    }

    // horizontal lines
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size - 1; x++) {
        const dx = spacing + x * spacing, dy = spacing + y * spacing;
        addLine(svg, lineMap, x, y, 'h', dx, dy, dx + spacing, dy);
      }
    }
    // vertical lines
    for (let y = 0; y < size - 1; y++) {
      for (let x = 0; x < size; x++) {
        const dx = spacing + x * spacing, dy = spacing + y * spacing;
        addLine(svg, lineMap, x, y, 'v', dx, dy, dx, dy + spacing);
      }
    }

    // dots (drawn last, on top)
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = spacing + x * spacing, dy = spacing + y * spacing;
        const c = document.createElementNS(SVG_NS, 'circle');
        c.setAttribute('cx', dx);
        c.setAttribute('cy', dy);
        c.setAttribute('r', 7);
        c.setAttribute('class', 'dot');
        svg.appendChild(c);
        const h = document.createElementNS(SVG_NS, 'circle');
        h.setAttribute('cx', dx - 2);
        h.setAttribute('cy', dy - 2);
        h.setAttribute('r', 2.4);
        h.setAttribute('class', 'dot-highlight');
        svg.appendChild(h);
      }
    }

    boardEls = { lines: lineMap, boxes: boxMap, size, spacing };
  }

  function addLine(svg, lineMap, x, y, type, x1, y1, x2, y2) {
    const hit = document.createElementNS(SVG_NS, 'line');
    hit.setAttribute('x1', x1); hit.setAttribute('y1', y1);
    hit.setAttribute('x2', x2); hit.setAttribute('y2', y2);
    hit.setAttribute('class', 'line-hit');
    hit.dataset.x = x; hit.dataset.y = y; hit.dataset.type = type;
    svg.appendChild(hit);

    const visible = document.createElementNS(SVG_NS, 'line');
    visible.setAttribute('x1', x1); visible.setAttribute('y1', y1);
    visible.setAttribute('x2', x2); visible.setAttribute('y2', y2);
    visible.setAttribute('class', 'line-visible');
    svg.appendChild(visible);

    hit.addEventListener('click', () => onLineTap(x, y, type));

    lineMap.set(`${x},${y},${type}`, { hit, visible });
  }

  let onLineTap = () => {}; // reassigned per game mode

  function renderState(state) {
    if (!boardEls || boardEls.size !== state.size) {
      buildBoard(el('board'), state.size);
    }
    for (const [key, { hit, visible }] of boardEls.lines) {
      const owner = state.lines[key];
      if (owner) {
        visible.setAttribute('class', `line-visible owner-${owner}`);
        hit.setAttribute('class', 'line-hit taken');
      } else {
        visible.setAttribute('class', 'line-visible');
        hit.setAttribute('class', 'line-hit');
      }
    }
    for (const [key, { rect, text }] of boardEls.boxes) {
      const owner = state.boxes[key];
      if (owner) {
        rect.setAttribute('fill', owner === 'S' ? 'var(--red-soft)' : 'var(--blue-soft)');
        text.setAttribute('fill', owner === 'S' ? 'var(--red)' : 'var(--blue)');
        text.textContent = (state.names[owner] || owner).charAt(0).toUpperCase();
      } else {
        rect.setAttribute('fill', 'transparent');
        text.setAttribute('fill', 'transparent');
        text.textContent = '';
      }
    }

    el('nameSLabel').textContent = state.names.S || 'Player 1';
    el('nameGLabel').textContent = state.names.G || 'Player 2';
    el('scoreSNum').textContent = state.score.S;
    el('scoreGNum').textContent = state.score.G;
    el('scoreS').classList.toggle('active-turn', state.turn === 'S' && !state.game_over);
    el('scoreG').classList.toggle('active-turn', state.turn === 'G' && !state.game_over);
    el('turnIndicator').textContent = state.game_over ? 'Khatam' : (state.turn === 'S' ? '➜' : '➜');
  }

  // ---------------------------------------------------------------
  // Winner modal
  // ---------------------------------------------------------------
  function showWinner(state) {
    const title = el('winnerTitle');
    const stats = el('winnerStats');
    let text;
    if (state.score.S > state.score.G) text = `🏆 ${state.names.S} Jeet Gaye!`;
    else if (state.score.G > state.score.S) text = `🏆 ${state.names.G} Jeet Gaye!`;
    else text = '🤝 Draw Ho Gaya!';
    title.textContent = text;
    stats.innerHTML = `
      <div>🔴 ${state.names.S}: <strong>${state.score.S}</strong> boxes</div>
      <div>🔵 ${state.names.G}: <strong>${state.score.G}</strong> boxes</div>`;
    el('winnerOverlay').classList.remove('hidden');
  }
  el('winnerCloseBtn').addEventListener('click', () => el('winnerOverlay').classList.add('hidden'));

  // =================================================================
  // LOCAL MODE
  // =================================================================
  let localState = null;
  let localHistory = [];
  let localVsAi = false;
  let localAiThinking = false;

  function newLocalGame() {
    const size = parseInt(el('boardSizeLocal').value, 10);
    localVsAi = el('vsAiCheck').checked;
    const nameS = (el('playerName').value || 'Player 1').trim() || 'Player 1';
    const nameG = localVsAi ? 'AI 🤖' : ((el('nameG_local').value || 'Player 2').trim() || 'Player 2');

    localState = {
      size, lines: {}, boxes: {}, score: { S: 0, G: 0 }, turn: 'S',
      names: { S: nameS, G: nameG }, game_over: false,
    };
    localHistory = [];
    boardEls = null;
    el('modeChip').textContent = localVsAi ? 'Local · vs AI' : 'Local · 2 Player';
    el('connStatus').classList.add('hidden');
    el('leaveOnlineBtn').classList.add('hidden');
    el('newLocalBtn').classList.remove('hidden');
    el('undoBtn').classList.remove('hidden');
    el('boardOverlayMsg').classList.add('hidden');
    showScreen('game');
    onLineTap = localLineTap;
    renderState(localState);
  }

  function snapshotLocal() {
    localHistory.push(JSON.parse(JSON.stringify({
      lines: localState.lines, boxes: localState.boxes, score: localState.score, turn: localState.turn,
    })));
    if (localHistory.length > 60) localHistory.shift();
  }

  function localCheckBox(x, y, turn) {
    const size = localState.size;
    if (x < 0 || y < 0 || x >= size - 1 || y >= size - 1) return false;
    const top = `${x},${y},h`, bottom = `${x},${y + 1},h`, left = `${x},${y},v`, right = `${x + 1},${y},v`;
    if (localState.lines[top] && localState.lines[bottom] && localState.lines[left] && localState.lines[right]) {
      const key = `${x},${y}`;
      if (!localState.boxes[key]) {
        localState.boxes[key] = turn;
        localState.score[turn]++;
        return true;
      }
    }
    return false;
  }

  function localApplyMove(x, y, type) {
    const key = `${x},${y},${type}`;
    if (localState.lines[key] || localState.game_over) return false;
    snapshotLocal();
    const turn = localState.turn;
    localState.lines[key] = turn;

    let madeBox = false;
    const size = localState.size;
    if (type === 'h') {
      if (y > 0) madeBox = localCheckBox(x, y - 1, turn) || madeBox;
      if (y < size - 1) madeBox = localCheckBox(x, y, turn) || madeBox;
    } else {
      if (x > 0) madeBox = localCheckBox(x - 1, y, turn) || madeBox;
      if (x < size - 1) madeBox = localCheckBox(x, y, turn) || madeBox;
    }
    if (!madeBox) localState.turn = turn === 'S' ? 'G' : 'S';

    const total = (size - 1) * (size - 1);
    if (Object.keys(localState.boxes).length >= total) localState.game_over = true;

    renderState(localState);
    if (localState.game_over) { setTimeout(() => showWinner(localState), 300); return true; }
    return true;
  }

  function localLineTap(x, y, type) {
    if (localState.game_over) return;
    if (localVsAi && localState.turn === 'G') return; // AI's turn
    if (localApplyMove(x, y, type) && localVsAi && localState.turn === 'G' && !localState.game_over) {
      setTimeout(runAiMove, 350);
    }
  }

  // ---- local AI ----
  function availableMoves() {
    const moves = [];
    const size = localState.size;
    for (let y = 0; y < size; y++)
      for (let x = 0; x < size - 1; x++)
        if (!localState.lines[`${x},${y},h`]) moves.push({ x, y, type: 'h' });
    for (let y = 0; y < size - 1; y++)
      for (let x = 0; x < size; x++)
        if (!localState.lines[`${x},${y},v`]) moves.push({ x, y, type: 'v' });
    return moves;
  }

  function boxesTouchedBy(m) {
    const size = localState.size, list = [];
    if (m.type === 'h') {
      if (m.y > 0) list.push([m.x, m.y - 1]);
      if (m.y < size - 1) list.push([m.x, m.y]);
    } else {
      if (m.x > 0) list.push([m.x - 1, m.y]);
      if (m.x < size - 1) list.push([m.x, m.y]);
    }
    return list;
  }

  function sidesFilled(x, y, extraKey) {
    const top = `${x},${y},h`, bottom = `${x},${y + 1},h`, left = `${x},${y},v`, right = `${x + 1},${y},v`;
    let c = 0;
    if (localState.lines[top] || top === extraKey) c++;
    if (localState.lines[bottom] || bottom === extraKey) c++;
    if (localState.lines[left] || left === extraKey) c++;
    if (localState.lines[right] || right === extraKey) c++;
    return c;
  }

  function movesCompleted(m) {
    const key = `${m.x},${m.y},${m.type}`;
    let c = 0;
    for (const [bx, by] of boxesTouchedBy(m)) {
      if (!localState.boxes[`${bx},${by}`] && sidesFilled(bx, by, key) === 4) c++;
    }
    return c;
  }

  function givesAwayBox(m) {
    const key = `${m.x},${m.y},${m.type}`;
    for (const [bx, by] of boxesTouchedBy(m)) {
      if (!localState.boxes[`${bx},${by}`] && sidesFilled(bx, by, key) === 3) return true;
    }
    return false;
  }

  function runAiMove() {
    if (localState.game_over || !localVsAi || localState.turn !== 'G' || localAiThinking) return;
    localAiThinking = true;
    const msg = el('boardOverlayMsg');
    msg.textContent = '🤖 AI soch rahi hai…';
    msg.classList.remove('hidden');

    setTimeout(() => {
      const difficulty = el('aiDifficulty').value;
      const moves = availableMoves();
      if (moves.length === 0) { localAiThinking = false; msg.classList.add('hidden'); return; }

      let chosen;
      if (difficulty === 'easy') {
        const completing = moves.filter(m => movesCompleted(m) > 0);
        chosen = (completing.length && Math.random() < 0.6)
          ? completing[Math.floor(Math.random() * completing.length)]
          : moves[Math.floor(Math.random() * moves.length)];
      } else {
        const completing = moves.map(m => ({ m, c: movesCompleted(m) })).filter(o => o.c > 0).sort((a, b) => b.c - a.c);
        if (completing.length) {
          chosen = completing[0].m;
        } else {
          const safe = moves.filter(m => !givesAwayBox(m));
          if (safe.length) {
            if (difficulty === 'hard') {
              let bestScore = -Infinity, cands = [];
              for (const m of safe) {
                const key = `${m.x},${m.y},${m.type}`;
                localState.lines[key] = 'G';
                const remain = availableMoves().filter(mm => !givesAwayBox(mm)).length;
                delete localState.lines[key];
                if (remain > bestScore) { bestScore = remain; cands = [m]; }
                else if (remain === bestScore) cands.push(m);
              }
              chosen = cands[Math.floor(Math.random() * cands.length)];
            } else {
              chosen = safe[Math.floor(Math.random() * safe.length)];
            }
          } else {
            const scored = moves.map(m => {
              let minChain = 4;
              for (const [bx, by] of boxesTouchedBy(m)) {
                if (!localState.boxes[`${bx},${by}`]) {
                  const s = sidesFilled(bx, by, `${m.x},${m.y},${m.type}`);
                  if (s < minChain) minChain = s;
                }
              }
              return { m, minChain };
            }).sort((a, b) => a.minChain - b.minChain);
            chosen = scored[0].m;
          }
        }
      }

      localApplyMove(chosen.x, chosen.y, chosen.type);
      localAiThinking = false;
      msg.classList.add('hidden');
      if (localVsAi && localState.turn === 'G' && !localState.game_over) {
        setTimeout(runAiMove, 350);
      }
    }, 450);
  }

  el('startLocalBtn').addEventListener('click', newLocalGame);
  el('newLocalBtn').addEventListener('click', newLocalGame);
  el('undoBtn').addEventListener('click', () => {
    if (!localState || localHistory.length === 0 || localState.game_over) return;
    const prev = localHistory.pop();
    localState.lines = prev.lines; localState.boxes = prev.boxes;
    localState.score = prev.score; localState.turn = prev.turn;
    renderState(localState);
  });

  // =================================================================
  // ONLINE MODE
  // =================================================================
  let socket = null;
  let onlineCode = null;
  let onlineRole = null;
  let onlineState = null;

  function ensureSocket() {
    if (socket) return socket;
    socket = io({ transports: ['websocket', 'polling'] });

    socket.on('connect', () => setConnStatus(true));
    socket.on('disconnect', () => setConnStatus(false));

    socket.on('room_created', (data) => {
      onlineCode = data.code; onlineRole = data.role; onlineState = data.state;
      el('roomCodeText').textContent = onlineCode;
      showScreen('wait');
    });

    socket.on('join_error', (data) => {
      el('joinError').textContent = data.message;
      el('joinRoomBtn').disabled = false;
    });

    socket.on('room_joined', (data) => {
      onlineCode = data.code; onlineRole = data.role; onlineState = data.state;
    });

    socket.on('opponent_joined', () => toast('Opponent join ho gaya! 🎮', 'success'));

    socket.on('game_start', (data) => {
      onlineState = data.state;
      startOnlineGameScreen();
    });

    socket.on('state_update', (data) => {
      onlineState = data.state;
      renderState(onlineState);
      if (onlineState.game_over) setTimeout(() => showWinner(onlineState), 300);
    });

    socket.on('opponent_left', (data) => {
      onlineState = data.state;
      toast('Opponent disconnect ho gaya…', 'error');
      const msg = el('boardOverlayMsg');
      if (screens.game.classList.contains('hidden')) return;
      msg.textContent = 'Opponent chala gaya. Naya room banao ya wait karo ki wapas aaye.';
      msg.classList.remove('hidden');
    });

    return socket;
  }

  function setConnStatus(ok) {
    const dot = el('connDot'), text = el('connText');
    dot.classList.toggle('offline', !ok);
    text.textContent = ok ? 'Connected' : 'Reconnecting…';
  }

  function startOnlineGameScreen() {
    boardEls = null;
    el('modeChip').textContent = `Online · Room ${onlineCode}`;
    el('connStatus').classList.remove('hidden');
    el('leaveOnlineBtn').classList.remove('hidden');
    el('undoBtn').classList.add('hidden');
    el('newLocalBtn').classList.add('hidden');
    el('boardOverlayMsg').classList.add('hidden');
    showScreen('game');
    onLineTap = onlineLineTap;
    renderState(onlineState);
  }

  function onlineLineTap(x, y, type) {
    if (!onlineState || onlineState.game_over) return;
    if (onlineState.turn !== onlineRole) { toast('Ye tumhari turn nahi hai'); return; }
    socket.emit('make_move', { code: onlineCode, x, y, type });
  }

  el('createRoomBtn').addEventListener('click', () => {
    const name = el('playerName').value;
    const size = el('boardSizeCreate').value;
    ensureSocket().emit('create_room', { name, size });
  });

  el('joinRoomBtn').addEventListener('click', () => {
    const code = el('joinCodeInput').value.trim().toUpperCase();
    if (code.length < 4) { el('joinError').textContent = 'Sahi room code daalo.'; return; }
    el('joinError').textContent = '';
    el('joinRoomBtn').disabled = true;
    const name = el('playerName').value;
    ensureSocket().emit('join_room_req', { code, name });
  });

  el('roomCodeBtn').addEventListener('click', () => {
    if (!onlineCode) return;
    navigator.clipboard?.writeText(onlineCode).then(() => toast('Code copy ho gaya!', 'success'));
  });

  el('cancelWaitBtn').addEventListener('click', () => {
    if (socket && onlineCode) socket.emit('leave_room_req', { code: onlineCode });
    onlineCode = null;
    showScreen('lobby');
  });

  el('leaveOnlineBtn').addEventListener('click', () => {
    if (socket && onlineCode) socket.emit('leave_room_req', { code: onlineCode });
    onlineCode = null; onlineState = null;
    showScreen('lobby');
  });

  el('backBtn').addEventListener('click', () => {
    if (onlineCode && socket) socket.emit('leave_room_req', { code: onlineCode });
    onlineCode = null;
    el('winnerOverlay').classList.add('hidden');
    showScreen('lobby');
  });

  // Enter key convenience
  el('joinCodeInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') el('joinRoomBtn').click(); });
  el('playerName').addEventListener('keydown', (e) => { if (e.key === 'Enter') e.target.blur(); });
})();
