# Dots & Boxes — Online Multiplayer

Flask + Flask-SocketIO backend, SVG board, local (2-player / vs AI) aur
online room-based multiplayer dono modes ek hi app mein.

## Render pe deploy (step by step)

1. Is poore `dotsboxes` folder ko ek GitHub repo mein push karo.
2. [render.com](https://render.com) pe jao → **New +** → **Web Service**.
3. Apna GitHub repo select karo.
4. Settings:
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn --worker-class eventlet -w 1 app:app`
     (Yeh already `Procfile` mein hai, Render usko khud pick kar leta hai —
     agar UI mein Start Command field khali chhod doge to bhi chalega)
5. **Instance Type**: Free bhi chalega testing ke liye.
6. Deploy dabao — kuch minute mein `https://your-app-name.onrender.com` URL mil jayega.

**Zaroori:** `-w 1` (sirf 1 worker) rakhna hi hai jab tak `rooms` dict ko
Redis jaisi shared store mein move nahi karte — kyunki abhi rooms sirf
uss ek worker ki memory mein hain. Free tier pe already 1 worker hi milta
hai, to yeh default sahi hai.

## Telegram Mini App mein lagana

1. `@BotFather` ko Telegram pe message karo → `/newbot` (agar bot nahi hai).
2. `/mybots` → apna bot chuno → **Bot Settings** → **Menu Button** →
   apna Render URL (`https://your-app-name.onrender.com`) daal do.
3. Bas — bot ke menu button se ab tumhara game Telegram ke andar khulega.

(Chaho to baad mein Telegram WebApp JS SDK add karke user ka Telegram naam
automatically le sakte ho, manual naam type karwane ki jagah — abhi ke
liye manual naam field already kaam karta hai.)

## Local testing (apne PC/Termux pe)

```bash
pip install -r requirements.txt
python app.py
```

Phir browser mein `http://localhost:5000` kholo.

## Structure

```
app.py                 → Flask + SocketIO backend, saara game logic/validation
templates/index.html   → Lobby, wait-room, game screen, winner modal
static/css/style.css   → Poora UI styling
static/js/main.js      → SVG board renderer, local AI, Socket.IO client
requirements.txt       → Dependencies
Procfile                → Render start command
```
